<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'edertton_wp16');

/** MySQL database username */
define('DB_USER', 'edertton_wp16');

/** MySQL database password */
define('DB_PASSWORD', 'x863t7EVuQ6YwQcn');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Sn?kZi_9Tn0g3X_?=XA,PDBiF%:tW9-!N?h7nE OM5L-9`5[6OGriS`1U]N@[x]8');
define('SECURE_AUTH_KEY',  'rCO<0L,w;0i:cWyIh>p? G#qnVZ8`}4u/IL@[QE](:.inc]`EBfEGNT~Y-!C4|?`');
define('LOGGED_IN_KEY',    '>!ef]Bh}zvt!`m{CPT2@V&|@+89_bi:tL|.E],c5XoC{%$P_P[i0Ba;_b^0f?w[7');
define('NONCE_KEY',        'j85{JOrqkYP:eIi11sdiM(0G[u+0-6<62>Z.w,nA2TGnrPpCj9>KJu6/*<+ rnM_');
define('AUTH_SALT',        'BHMDEA+<2oE-/I,%),}llE<[@c7cL+.?+9c^w $F`Jfk^-`]i=Af=@Ye(><7&G,e');
define('SECURE_AUTH_SALT', '`o[vatuDPqI.Rcb&%*:(M]64IDn%Ecb<En.v{Z,=[RkbW%^Li3Jvq;SIFAe|I+^8');
define('LOGGED_IN_SALT',   '(.^xX*r<yKJ9Wd7)^K]`)Fk~lb~ V(VY3`^BUuu_@pu(>$gL0zR=LJ N~Kgxz8`~');
define('NONCE_SALT',       'wIdaX:s%K)c4it&lDLKiX;lM6~5$0ItJx_uJ]5XAvWa+xYuE}(eH*#8P0#7p[i`w');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
